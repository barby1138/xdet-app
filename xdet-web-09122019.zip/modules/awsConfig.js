{ "accessKeyId": "AKIAIWAPG4G7NT7CD4EA", "secretAccessKey": "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", "region": "eu-west-2" }
