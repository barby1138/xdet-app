
const det = require('./modules/det_processor');