#!/bin/bash

DATA_FOLDER=../data

FILES=($DATA_FOLDER/infly/*.xml); echo to_proc: ; echo ${#FILES[@]}

FILES=($DATA_FOLDER/processed/*.xml); echo processed: ; echo ${#FILES[@]}

FILES=($DATA_FOLDER/store/*.xml); echo store: ; echo ${#FILES[@]}

FILES=($DATA_FOLDER/archive/x0/PH/*.wav); echo arch wav: ; echo ${#FILES[@]}

FILES=($DATA_FOLDER/archive/x0/PH/*.mp4); echo arch mp4: ; echo ${#FILES[@]}
