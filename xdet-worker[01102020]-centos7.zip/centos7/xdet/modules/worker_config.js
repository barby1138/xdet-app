module.exports = Object.freeze({
    // GENERIC
    USER_ID: 'x0',
    //S3_BUCKET: 'xdet'

    // DET PROC
    DATA_FOLDER: '/home/alex/data',
    DET_MAX_INFLY_THSHLD: 320 * 3,

    //DL CALLER
    DL_CALLER_Q_MAX_THSHLD: 300,
    DL_CALLER_Q_MIN_THSHLD: 100,
    CALLDLQ_TO_MSEC: 1 * 60 * 60 * 1000,

    //DL SOURCE
    DL_MAX_RETRIES: 3,
    DL_MAX_CNT: 20,
    DL_Q_MIN_THSHLD: 500,
    COMMON_POLL_TO_MSEC: 10000,
    ARCH_PATH: '/home/alex/data/archive/x0/PH'

});
